﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Linq;
using System.ServiceProcess;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Timers;
using System.Data.SqlClient;
namespace WindowsServicesTrial1
{
    public partial class Service1 : ServiceBase
    {
        private Timer timer;
        private string filePath = "C:_Program Files_Microsoft SQL Server_MSSQL16.MSSQLSERVER_MSSQL_Backup";
        string connectionstring = ConfigurationManager.ConnectionStrings["DBConnectionString"].ConnectionString;
        public Service1()
        {
            InitializeComponent();
        }

        protected override void OnStart(string[] args)
        {
            // Set up the timer interval (e.g., every 5 seconds)
            int interval = 5000;
            timer = new Timer();
            timer.Interval = interval;
            timer.Elapsed += TimerElapsed;
            timer.Start();

        }

        protected override void OnStop()
        {
            timer.Stop();
            timer.Dispose();
        }
        private void TimerElapsed(object sender, ElapsedEventArgs e)
        {
            // Perform the script execution here
            string script = System.IO.File.ReadAllText(filePath);

            using (SqlConnection connection = new SqlConnection(connectionstring))
            {
                try
                {
                    connection.Open();
                    SqlCommand command = new SqlCommand(script, connection);
                    command.CommandType = CommandType.Text;

                    // Execute the script
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // Handle any exceptions
                    Console.WriteLine("An error occurred: " + ex.Message);
                }
            }
        }
    }
}